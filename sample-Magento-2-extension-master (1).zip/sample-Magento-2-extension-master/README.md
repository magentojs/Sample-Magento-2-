# Tm_ProductList
Create a product list with grid and slider mode under customer account navigation with menu item
friendsofphp
# Key Features :

1. set product to show under Tm Product list section of my account.

2. Can set number of product to display in Tm ProductList section.

2. Define grid and Slider mode view.

3. Responsive layout.

