var config = {
	 map: {
        '*': {
            owlCarousel: 'Tm_ProductList/js/owl.carousel'
        }
    }

};
